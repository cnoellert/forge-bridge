"""Full-page /ui/* route handlers for the v1.3 Artist Console Web UI.

Every handler reads through request.app.state.console_read_api (the
ConsoleReadAPI singleton from Phase 9). No handler parses JSONL, queries
ManifestService internals, or touches ExecutionLog fields directly -- the
instance-identity gate (Phase 9 API-04) silently enforces this at runtime.

Handler contract (mirrors handlers.py):
  - Wrap body in try/except Exception
  - Log type(exc).__name__ at WARNING with exc_info=True
  - NEVER leak tracebacks
  - Return TemplateResponse (errors/read_failed.html for 500)
"""
from __future__ import annotations

import logging
import os
from pathlib import Path

from starlette.requests import Request
from starlette.responses import HTMLResponse, RedirectResponse

from forge_bridge.console.manifest_service import ToolRecord

logger = logging.getLogger(__name__)

# Path to synthesized tool source files (T-10-18: confined to SYNTH_ROOT)
_SYNTH_ROOT = Path(os.environ.get(
    "FORGE_SYNTH_ROOT",
    str(Path.home() / ".forge-bridge" / "tools" / "synth"),
))


# -- Helper: map query_params -> token string for D-26 pre-population --

_TOOLS_KEYS = ["origin", "namespace", "readonly", "q"]
_EXECS_KEYS = ["tool", "since", "until", "promoted", "hash"]
_MANIFEST_KEYS = ["q", "status"]

# API-param -> UI-grammar key reverse mapping (see fragments/query_console.html parse())
_API_TO_UI_KEY = {
    "promoted_only": "promoted",
    "code_hash": "hash",
}


def _query_params_as_tokens(query_params, supported_keys: list[str]) -> str:
    """D-26: reconstruct a `key:value key:value` token string from URL params
    so the query console input is pre-populated on first paint."""
    tokens = []
    for k, v in query_params.items():
        if k in ("limit", "offset"):
            continue  # pagination stays out of the query console
        ui_key = _API_TO_UI_KEY.get(k, k)
        if ui_key in supported_keys:
            tokens.append(f"{ui_key}:{v}")
        elif k in supported_keys:
            tokens.append(f"{k}:{v}")
    return " ".join(tokens)


def _render_error(request: Request, template: str, message: str, status: int) -> HTMLResponse:
    return request.app.state.templates.TemplateResponse(
        request,
        template,
        {"message": message, "active_view": None},
        status_code=status,
    )


def _tools_preset_chips() -> list:
    """D-09 + Phase 10.1 D-40 triage (b): preset chip roster for the tools view.

    The Phase 10 quarantine chip was dropped in Phase 10.1 because its token
    string was a substring filter against tool names (not a status field) and
    probation-quarantined tools are deleted from ManifestService by the
    watcher's removal-mirror path (watcher.py:278-293 after
    probation.py:71-88). Locked by tests/test_tool_quarantine_surface.py.
    """
    return [
        {"label": "Synth only", "tokens": "origin:synthesized"},
        {"label": "Builtin only", "tokens": "origin:builtin"},
    ]


def _derive_tool_status(tool: "ToolRecord") -> str:
    """D-40 status derivation for the Tools-view Status column.

    Mirrors the manifest-view _filter_manifest_entries precedent at
    lines 326-357 -- derived server-side from ToolRecord fields so the
    template stays thin. Returns one of two values in Phase 10.1:

      - "active":  synthesized tool with a code_hash AND observation_count > 0
      - "loaded":  everything else visible in get_tools() -- builtin tools,
                   synthesized tools with no observations, synthesized tools
                   with a missing code_hash.

    The "quarantined" status does NOT appear here by design: quarantined
    tools are removed from ManifestService by the watcher's removal-mirror
    path (forge_bridge/learning/watcher.py:278-293) after
    ProbationTracker.quarantine() (forge_bridge/learning/probation.py:71-88)
    fires, so they are never in the get_tools() stream. Locked by
    tests/test_tool_quarantine_surface.py. If that test fails, this
    function and forge-console.css's chip variant set must be re-planned.

    Signature accepts ToolRecord directly (not dict) because the sole call
    site -- the `ui_tools_handler` TemplateResponse comprehension -- iterates
    `filtered: list[ToolRecord]` BEFORE `.to_dict()` is applied.
    """
    if (
        tool.origin == "synthesized"
        and tool.code_hash
        and (tool.observation_count or 0) > 0
    ):
        return "active"
    return "loaded"


def _filter_tools(tools, qp):
    """Apply UI-grammar filters to get_tools() result.

    v1.3 does filtering in-Python because /api/v1/tools has no server-side
    filter params (D-23 — structured query console + preset chips are the
    only filter surface in v1.3).
    """
    origin = qp.get("origin")
    namespace = qp.get("namespace")
    readonly = qp.get("readonly")
    q = (qp.get("q") or "").lower()
    out = []
    for t in tools:
        if origin and t.origin != origin:
            continue
        if namespace and t.namespace != namespace:
            continue
        if readonly is not None:
            m = dict(t.meta) if t.meta else {}
            if str(m.get("read_only_hint", "")).lower() != readonly.lower():
                continue
        if q and q not in t.name.lower():
            continue
        out.append(t)
    return out


def _read_synth_source(name: str) -> str | None:
    """Best-effort: read raw source for a synthesized tool.

    Returns None if the file is missing or unreadable. Includes path-traversal
    guard (T-10-18): verifies the resolved path is still under _SYNTH_ROOT
    before reading.
    """
    candidate = _SYNTH_ROOT / f"{name}.py"
    try:
        resolved = candidate.resolve()
        try:
            resolved.relative_to(_SYNTH_ROOT.resolve())
        except ValueError:
            # Path escaped SYNTH_ROOT — reject silently (traversal attempt)
            return None
        if resolved.is_file():
            return resolved.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        logger.warning(
            "_read_synth_source failed for %s: %s",
            name, type(exc).__name__, exc_info=True,
        )
    return None


# -- Root redirect ----------------------------------------------------------

async def ui_index_handler(request: Request) -> HTMLResponse:
    """Redirect /ui/ -> /ui/tools (the default view)."""
    return RedirectResponse(url="/ui/tools", status_code=302)


# -- Tools view ---------------------------------------------------------------

async def ui_tools_handler(request: Request) -> HTMLResponse:
    """Full-page /ui/tools handler. Implements TOOLS-01 + CONSOLE-03."""
    try:
        tools = await request.app.state.console_read_api.get_tools()
    except Exception as exc:
        logger.warning(
            "ui_tools_handler failed: %s", type(exc).__name__, exc_info=True,
        )
        return _render_error(
            request, "errors/read_failed.html",
            "Could not load tools — the console API may be restarting. Refresh to try again.",
            500,
        )
    filtered = _filter_tools(tools, dict(request.query_params))
    querystring = "?" + str(request.query_params) if request.query_params else ""
    return request.app.state.templates.TemplateResponse(
        request,
        "tools/list.html",
        {
            "active_view": "tools",
            "tools": [
                {**t.to_dict(), "status": _derive_tool_status(t)}
                for t in filtered
            ],
            "query_params": dict(request.query_params),
            "query_params_as_tokens": _query_params_as_tokens(
                request.query_params, _TOOLS_KEYS,
            ),
            "querystring": querystring,
            "view_slug": "tools",
            "preset_chips": _tools_preset_chips(),
            "supported_keys": _TOOLS_KEYS,
        },
    )


async def ui_tool_detail_handler(request: Request) -> HTMLResponse:
    """Drilldown /ui/tools/{name} handler. Implements TOOLS-02."""
    name = request.path_params["name"]
    try:
        tool = await request.app.state.console_read_api.get_tool(name)
    except Exception as exc:
        logger.warning(
            "ui_tool_detail_handler failed: %s", type(exc).__name__, exc_info=True,
        )
        return _render_error(
            request, "errors/read_failed.html",
            "Could not load tool detail — the console API may be restarting.",
            500,
        )
    if tool is None:
        return _render_error(
            request, "errors/not_found.html",
            f"No tool named {name!r}.",
            404,
        )
    raw_code = None
    if tool.origin == "synthesized":
        raw_code = _read_synth_source(name)
    return request.app.state.templates.TemplateResponse(
        request,
        "tools/detail.html",
        {
            "active_view": "tools",
            "tool": tool.to_dict(),
            "raw_code": raw_code,
        },
    )


# -- Execs view ---------------------------------------------------------------

def _execs_preset_chips() -> list:
    """D-09: preset chip roster for the execs view.

    'Last 24h' requires a client-computed ISO timestamp; for v1.3 we ship
    two absolute chips instead (planner recommendation — scope note in plan).
    """
    return [
        {"label": "Promoted only", "tokens": "promoted:true"},
        {"label": "Hash prefix", "tokens": "hash:abcd"},
    ]


async def ui_execs_handler(request: Request) -> HTMLResponse:
    """Full-page /ui/execs handler. Implements EXECS-01 + CONSOLE-03."""
    from dataclasses import asdict
    from forge_bridge.console.handlers import _parse_pagination, _parse_filters
    try:
        limit, offset = _parse_pagination(request)
        try:
            since, promoted_only, code_hash = _parse_filters(request)
        except ValueError as ve:
            return _render_error(
                request, "errors/read_failed.html",
                f"Could not load executions — {ve}",
                400,
            )
        records, total = await request.app.state.console_read_api.get_executions(
            limit=limit, offset=offset, since=since,
            promoted_only=promoted_only, code_hash=code_hash,
        )
    except Exception as exc:
        logger.warning(
            "ui_execs_handler failed: %s", type(exc).__name__, exc_info=True,
        )
        return _render_error(
            request, "errors/read_failed.html",
            "Could not load execution history — the console API may be restarting.",
            500,
        )
    # Build filter_querystring (filters only, no limit/offset — so pagination
    # links preserve filter state without multiplying pagination params).
    filter_parts = []
    for key in ("since", "promoted_only", "code_hash"):
        val = request.query_params.get(key)
        if val:
            filter_parts.append(f"&{key}={val}")
    filter_qs = "".join(filter_parts)
    querystring = "?" + str(request.query_params) if request.query_params else ""
    return request.app.state.templates.TemplateResponse(
        request,
        "execs/list.html",
        {
            "active_view": "execs",
            "records": [asdict(r) for r in records],
            "total": total,
            "limit": limit,
            "offset": offset,
            "querystring": querystring,
            "filter_querystring": filter_qs,
            "query_params": dict(request.query_params),
            "query_params_as_tokens": _query_params_as_tokens(
                request.query_params, _EXECS_KEYS,
            ),
            "view_slug": "execs",
            "preset_chips": _execs_preset_chips(),
            "supported_keys": _EXECS_KEYS,
        },
    )


async def ui_exec_detail_handler(request: Request) -> HTMLResponse:
    """Drilldown /ui/execs/{code_hash}/{timestamp} handler. Implements EXECS-02."""
    from dataclasses import asdict
    code_hash = request.path_params["code_hash"]
    timestamp = request.path_params["timestamp"]
    try:
        # Find the record: ask for records matching this hash prefix; match timestamp.
        records, _ = await request.app.state.console_read_api.get_executions(
            limit=500, offset=0, code_hash=code_hash,
        )
    except Exception as exc:
        logger.warning(
            "ui_exec_detail_handler failed: %s", type(exc).__name__, exc_info=True,
        )
        return _render_error(
            request, "errors/read_failed.html",
            "Could not load execution detail.",
            500,
        )
    match = next(
        (r for r in records if r.code_hash == code_hash and r.timestamp == timestamp),
        None,
    )
    if match is None:
        return _render_error(
            request, "errors/not_found.html",
            f"No execution recorded for hash {code_hash[:8]!r} at {timestamp!r}.",
            404,
        )
    return request.app.state.templates.TemplateResponse(
        request,
        "execs/detail.html",
        {
            "active_view": "execs",
            "record": asdict(match),
        },
    )


# -- Manifest view -----------------------------------------------------------

def _manifest_preset_chips() -> list:
    """D-09: preset chip roster for the manifest view."""
    return [
        {"label": "Loaded", "tokens": "status:loaded"},
        {"label": "Orphaned", "tokens": "status:orphaned"},
    ]


def _filter_manifest_entries(entries: list, qp: dict) -> list:
    """Apply q + status filters to manifest entries from get_manifest()['tools'].

    Status derivation:
    - active: has code_hash AND observation_count > 0
    - loaded: has code_hash but observation_count == 0
    - orphaned: no code_hash (missing sidecar)

    status=orphaned filter: observation_count == 0 OR code_hash missing.
    status=loaded filter: has code_hash (any obs count).
    """
    q = (qp.get("q") or "").lower()
    status = (qp.get("status") or "").lower()
    out = []
    for e in entries:
        if q and q not in e.get("name", "").lower():
            continue
        if status == "orphaned":
            if e.get("observation_count", 0) > 0 and e.get("code_hash"):
                continue
        elif status == "loaded":
            if not e.get("code_hash"):
                continue
        # Decorate each entry with a derived status label for the table
        if e.get("code_hash") and e.get("observation_count", 0) > 0:
            e = {**e, "status": "active"}
        elif not e.get("code_hash"):
            e = {**e, "status": "orphaned"}
        else:
            e = {**e, "status": "loaded"}
        out.append(e)
    return out


async def ui_manifest_handler(request: Request) -> HTMLResponse:
    """Full-page /ui/manifest handler. Implements MFST-04 + CONSOLE-03."""
    try:
        manifest = await request.app.state.console_read_api.get_manifest()
    except Exception as exc:
        logger.warning(
            "ui_manifest_handler failed: %s", type(exc).__name__, exc_info=True,
        )
        return _render_error(
            request, "errors/read_failed.html",
            "Could not load manifest — the console API may be restarting.",
            500,
        )
    filtered = _filter_manifest_entries(
        list(manifest.get("tools", [])), dict(request.query_params),
    )
    querystring = "?" + str(request.query_params) if request.query_params else ""
    return request.app.state.templates.TemplateResponse(
        request,
        "manifest/list.html",
        {
            "active_view": "manifest",
            "manifest": manifest,
            "entries": filtered,
            "querystring": querystring,
            "query_params": dict(request.query_params),
            "query_params_as_tokens": _query_params_as_tokens(
                request.query_params, _MANIFEST_KEYS,
            ),
            "view_slug": "manifest",
            "preset_chips": _manifest_preset_chips(),
            "supported_keys": _MANIFEST_KEYS,
        },
    )


# -- Health dedicated view ---------------------------------------------------

async def ui_health_view_handler(request: Request) -> HTMLResponse:
    """Full-page /ui/health handler. Implements HEALTH-01."""
    try:
        health = await request.app.state.console_read_api.get_health()
    except Exception as exc:
        logger.warning(
            "ui_health_view_handler failed: %s", type(exc).__name__, exc_info=True,
        )
        return _render_error(
            request, "errors/read_failed.html",
            "Could not load health status.",
            500,
        )
    return request.app.state.templates.TemplateResponse(
        request,
        "health/detail.html",
        {
            "active_view": "health",
            "health": health,
        },
    )


# -- Chat panel (Phase 16 / FB-D — live panel replaces D-28/D-29 nav stub) --

async def ui_chat_handler(request: Request) -> HTMLResponse:
    """GET /ui/chat — Phase 16 (FB-D) live chat panel.

    Renders chat/panel.html which mounts the Alpine.js chatPanel() factory
    from /ui/static/forge-chat.js. The panel posts to /api/v1/chat (Phase 16
    plan 16-04). Per D-06, all conversation state lives in browser JS and
    clears on tab close — no server-side history persistence.
    """
    return request.app.state.templates.TemplateResponse(
        request,
        "chat/panel.html",
        {
            "active_view": "chat",
        },
    )
