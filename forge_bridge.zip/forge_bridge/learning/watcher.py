"""Asyncio watcher for synthesized MCP tools.

Polls a directory for .py files, hot-loads them via importlib,
and registers/deregisters via the MCP registry.
"""
from __future__ import annotations

import asyncio
import hashlib
import importlib.util
import json as _json
import logging
from pathlib import Path
from typing import TYPE_CHECKING

from forge_bridge.learning.manifest import manifest_verify, MANIFEST_PATH
from forge_bridge.learning.sanitize import _sanitize_tag, apply_size_budget

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP

    from forge_bridge.console.manifest_service import ManifestService
    from forge_bridge.learning.probation import ProbationTracker

logger = logging.getLogger(__name__)

# Default: ~/.forge-bridge/synthesized/
# Matches LEARN-02 location pattern for runtime data
SYNTHESIZED_DIR = Path.home() / ".forge-bridge" / "synthesized"

_POLL_INTERVAL = 5.0  # seconds


async def watch_synthesized_tools(
    mcp: "FastMCP",
    synthesized_dir: Path | None = None,
    poll_interval: float = _POLL_INTERVAL,
    tracker: "ProbationTracker | None" = None,
    manifest_service: "ManifestService | None" = None,
) -> None:
    """Asyncio polling loop: hot-load new/changed synthesized tools.

    manifest_service: optional -- when provided, every successfully-registered
        synthesized tool is also entered into the ManifestService by name,
        keeping the in-memory synthesis manifest in lock-step with the
        live MCP tool registry. Backward-compatible default of None
        preserves Phase 3-8 behavior.
    """
    synth_dir = synthesized_dir or SYNTHESIZED_DIR
    seen: dict[str, str] = {}  # stem -> sha256

    while True:
        await asyncio.sleep(poll_interval)
        try:
            _scan_once(
                mcp, seen, synth_dir,
                tracker=tracker, manifest_service=manifest_service,
            )
        except Exception:
            logger.exception("Error in synthesized tool watcher")


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _read_sidecar(py_path: Path) -> dict | None:
    """Load the sidecar envelope for a synthesized tool.

    Prefers `<stem>.sidecar.json` (v1.2+), falls back to legacy `<stem>.tags.json`
    (v1.1) for a grace window. Applies `_sanitize_tag` to every consumer-supplied
    tag at the READ boundary (PROV-03 defense-in-depth), then `apply_size_budget`
    to enforce <= 16 tags and <= 4 KB `meta`. Always prepends the literal
    `"synthesized"` tag so clients can filter (TS-02.1).

    Returns:
        dict of shape `{"tags": [...], "meta": {...}}` on success, or None if
        no sidecar exists OR the sidecar is malformed (non-JSON, non-dict).
    """
    sidecar_path = py_path.with_suffix(".sidecar.json")
    legacy_path = py_path.with_suffix(".tags.json")

    raw: dict | None = None
    if sidecar_path.exists():
        try:
            loaded = _json.loads(sidecar_path.read_text())
        except _json.JSONDecodeError:
            logger.warning("malformed .sidecar.json for %s — skipping provenance", py_path.stem)
            return None
        if not isinstance(loaded, dict):
            logger.warning(
                ".sidecar.json for %s is not a JSON object — skipping provenance",
                py_path.stem,
            )
            return None
        # Type-guard consumer-supplied fields. Without this, a non-list `tags`
        # (e.g. `"tags": "project:acme"`) iterates CHARACTERS downstream, and a
        # non-dict `meta` (e.g. `"meta": 42`) crashes `dict(raw["meta"])`.
        tags_field = loaded.get("tags")
        if tags_field is not None and not isinstance(tags_field, list):
            logger.warning(
                ".sidecar.json for %s has non-list tags field — skipping provenance",
                py_path.stem,
            )
            return None
        meta_field = loaded.get("meta")
        if meta_field is not None and not isinstance(meta_field, dict):
            logger.warning(
                ".sidecar.json for %s has non-dict meta field — skipping provenance",
                py_path.stem,
            )
            return None
        raw = {
            "tags": tags_field or [],
            "meta": meta_field or {},
        }
    elif legacy_path.exists():
        try:
            loaded = _json.loads(legacy_path.read_text())
        except _json.JSONDecodeError:
            logger.warning("malformed .tags.json for %s — skipping provenance", py_path.stem)
            return None
        if not isinstance(loaded, dict):
            logger.warning(
                ".tags.json for %s is not a JSON object — skipping provenance",
                py_path.stem,
            )
            return None
        tags_field = loaded.get("tags")
        if tags_field is not None and not isinstance(tags_field, list):
            logger.warning(
                ".tags.json for %s has non-list tags field — skipping provenance",
                py_path.stem,
            )
            return None
        raw = {
            "tags": tags_field or [],
            "meta": {},  # legacy shape has no meta block
        }
    else:
        return None

    # Sanitize each consumer tag; drop rejections silently (already logged by sanitize)
    sanitized_tags: list[str] = []
    for t in raw["tags"]:
        cleaned = _sanitize_tag(t)
        if cleaned is not None:
            sanitized_tags.append(cleaned)

    # Prepend the literal "synthesized" filter tag (TS-02.1 — unconditional)
    tags_out = ["synthesized"] + sanitized_tags

    payload = {"tags": tags_out, "meta": dict(raw["meta"])}
    return apply_size_budget(payload)


def _log_manifest_register_exception(task: "asyncio.Task") -> None:
    """done_callback for the manifest_service.register coroutine.

    Logs exceptions raised inside the scheduled register/remove tasks without
    surfacing them to the sync _scan_once caller. Mirrors the
    _log_callback_exception pattern in execution_log.py (LRN-02) so watcher
    side-effect failures do not crash the polling loop. Credential-safety
    practice: log only type(exc).__name__, not str(exc).
    """
    try:
        exc = task.exception()
    except asyncio.CancelledError:
        return
    if exc is not None:
        logger.warning(
            "manifest_service.register raised: %s", type(exc).__name__,
            exc_info=(type(exc), exc, exc.__traceback__),
        )


def _build_tool_record(stem: str, provenance: dict | None, digest: str):
    """Build a ToolRecord from watcher-side inputs.

    Lazy-imports ToolRecord to avoid a circular import cycle with
    forge_bridge.console (console reads from learning indirectly via
    the MCP tool registration callbacks).
    """
    from forge_bridge.console.manifest_service import ToolRecord

    # Infer namespace from stem prefix (flame_/forge_/synth_); default "synth"
    if stem.startswith("flame_"):
        namespace = "flame"
    elif stem.startswith("forge_"):
        namespace = "forge"
    else:
        namespace = "synth"

    # Extract meta from provenance if present; provenance may be None
    meta_src = (provenance or {}).get("meta") or {}
    # Normalize meta into stringified pairs for the frozen tuple
    meta_pairs = tuple((str(k), str(v)) for k, v in meta_src.items())
    tags = tuple(str(t) for t in (provenance or {}).get("tags", ()))

    # Derive optional fields from meta (sidecar schema)
    version = meta_src.get("version")
    synthesized_at = meta_src.get("synthesized_at")
    observation_count = int(meta_src.get("observation_count", 0) or 0)

    return ToolRecord(
        name=stem,
        origin="synthesized",
        namespace=namespace,
        synthesized_at=synthesized_at,
        code_hash=digest,
        version=version,
        observation_count=observation_count,
        tags=tags,
        meta=meta_pairs,
    )


def _scan_once(
    mcp: "FastMCP",
    seen: dict[str, str],
    synthesized_dir: Path,
    tracker: "ProbationTracker | None" = None,
    manifest_path: Path = MANIFEST_PATH,
    manifest_service: "ManifestService | None" = None,
) -> None:
    """Single scan pass — detect new, changed, and deleted files."""
    if not synthesized_dir.exists():
        return

    from forge_bridge.mcp.registry import register_tool

    current_stems: set[str] = set()
    for path in sorted(synthesized_dir.glob("*.py")):
        if path.stem.startswith("__"):
            continue
        stem = path.stem
        current_stems.add(stem)
        digest = _sha256(path)
        if seen.get(stem) == digest:
            continue
        # Manifest check — reject files not registered by the synthesizer
        if not manifest_verify(path, manifest_path=manifest_path):
            logger.warning(f"Skipping {stem}: not in manifest or hash mismatch")
            continue
        # New or changed file — (re)load
        if stem in seen:
            try:
                mcp.remove_tool(stem)
            except Exception:
                pass
        fn = _load_fn(path, stem)
        if fn is None:
            continue
        if tracker is not None:
            fn = tracker.wrap(fn, stem, mcp)
        try:
            provenance = _read_sidecar(path)
            register_tool(mcp, fn, name=stem, source="synthesized", provenance=provenance)
            seen[stem] = digest
            logger.info(f"Registered synthesized tool: {stem}")
            # If a ManifestService is injected, mirror the MCP registration into
            # the in-memory manifest. manifest_service.register is async; we are
            # sync-in-async (called from the watcher coroutine) so schedule the
            # coroutine via asyncio.create_task with a done-callback for errors.
            if manifest_service is not None:
                try:
                    record = _build_tool_record(stem, provenance, digest)
                    task = asyncio.create_task(manifest_service.register(record))
                    task.add_done_callback(_log_manifest_register_exception)
                except Exception:
                    logger.exception(
                        "Failed to schedule manifest register for %s", stem
                    )
        except ValueError as e:
            logger.warning(f"Skipped {stem}: {e}")

    # Remove tools whose files disappeared
    for stem in list(seen):
        if stem not in current_stems:
            try:
                mcp.remove_tool(stem)
                logger.info(f"Removed synthesized tool: {stem}")
            except Exception:
                pass
            # Mirror removal into the manifest service
            if manifest_service is not None:
                try:
                    task = asyncio.create_task(manifest_service.remove(stem))
                    task.add_done_callback(_log_manifest_register_exception)
                except Exception:
                    logger.exception(
                        "Failed to schedule manifest remove for %s", stem
                    )
            del seen[stem]


def _load_fn(path: Path, stem: str):
    """Load a Python file and return the callable named `stem`."""
    spec = importlib.util.spec_from_file_location(stem, path)
    if spec is None or spec.loader is None:
        return None
    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
    except Exception:
        logger.exception(f"Failed to load {path}")
        return None
    fn = getattr(module, stem, None)
    if not callable(fn):
        logger.warning(f"{path}: no callable named {stem!r}")
        return None
    return fn
